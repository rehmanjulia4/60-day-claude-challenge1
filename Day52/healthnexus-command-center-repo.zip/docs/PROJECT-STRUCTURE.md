# PROJECT-STRUCTURE.md — HealthNexus Command Center

**Day 52 of 60 · System Design**

## 1. Full Folder Tree

```
healthnexus-command-center/
├── .github/
│   └── workflows/
│       └── deploy.yml          # GitHub Pages deploy workflow
├── public/
│   ├── index.html               # Base shell, embedded React/Babel, base64 fonts
│   └── favicon.svg
├── src/
│   ├── App.jsx                  # Root component, tab/theme/lang state
│   ├── theme.css                # Design tokens (3 theme variants)
│   ├── components/
│   │   ├── IncidentQueue.jsx
│   │   ├── IncidentCard.jsx
│   │   ├── SummaryStrip.jsx
│   │   ├── FacilityFilterBar.jsx
│   │   ├── FacilityCompareStrip.jsx
│   │   ├── IncidentDetail.jsx
│   │   ├── RecommendationPanel.jsx
│   │   ├── SignOffForm.jsx
│   │   ├── ResolvedIncidents.jsx
│   │   └── ThemeSwitcher.jsx / LanguageSwitcher.jsx
│   ├── data/
│   │   ├── prng.js              # mulberry32 seeded PRNG
│   │   ├── schema.js             # JSDoc shapes: Facility, Incident, Recommendation, SignOff
│   │   ├── generateFacilities.js
│   │   ├── generateIncidents.js
│   │   └── generateRecommendation.js
│   ├── state/
│   │   └── incidentState.js      # The v1.0 "API" module (see API.md) — gated status transitions
│   └── i18n/
│       └── strings.js            # EN/AR string table
└── docs/
    ├── prd.md
    ├── blueprint.md
    ├── ARCHITECTURE.md
    ├── SCHEMA.md
    ├── API.md
    ├── UI-WIREFRAMES.md
    └── PROJECT-STRUCTURE.md      # this file
```

## 2. Folder Responsibilities

- **`public/`** — Everything shipped as-is to GitHub Pages. `index.html` is the single entry point; no build step transforms this folder.
- **`src/components/`** — All UI. Each file maps to exactly one wireframe from `UI-WIREFRAMES.md`. No component reaches into `data/` generators directly — everything goes through `state/incidentState.js`.
- **`src/data/`** — The synthetic data engine. Nothing here holds UI logic; it only produces plain data objects matching `schema.js`.
- **`src/state/`** — The governance boundary. `incidentState.js` is the only place `SignOff` objects are written and the only place `Incident.status` is derived. This is where the API.md contract lives in code.
- **`src/i18n/`** — Single source for every user-facing string in both languages, so Day 59 (bilingual/RTL) touches this file and layout CSS, not component logic.
- **`docs/`** — All planning and design artifacts, kept in the repo itself so a fresh AI conversation on any future day can read them directly instead of relying on chat history.

## 3. Where Future Code Lives

- New incident types (future scope, e.g. operational/compliance) would add new `type` enum values in `schema.js` and new generator logic in `data/`, without touching `components/`.
- A real backend (future scope) would replace `state/incidentState.js`'s internals with `fetch` calls to the endpoints listed in `API.md` §4, while every component's calling code stays identical, since the function signatures wouldn't change.

## 4. Why This Structure

- **Flat and shallow on purpose.** No nested feature-folder architecture — 9 remaining days don't justify that complexity, and PRD scope is a single-persona, single-workflow tool.
- **Data/state/components separated** specifically so the governance gate (`state/incidentState.js`) is one obvious file to audit, not logic scattered across components.
- **`docs/` lives in the repo**, not just in chat, satisfying the Day 51 Blueprint's requirement that "a fresh AI conversation could pick up exactly where the previous day left off."

## 5. Day 3 (Day 53) Readiness Check

- Remaining Blueprint (Days 53-60) is realistic against this structure — no folder or file introduces scope beyond what Day 51 approved.
- No scope creep found today. Tech stack, architecture, schema, API, and wireframes all confirm the Day 51 plan rather than expanding it.
- Tomorrow (Day 53) can begin implementation immediately: `src/data/prng.js` and the generators are the first files to write, per the existing Blueprint.
