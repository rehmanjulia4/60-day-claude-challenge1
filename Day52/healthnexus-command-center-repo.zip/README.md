# HealthNexus Command Center

AI-advised, clinician-governed clinical incident triage for a multi-facility health system COO.

Capstone project, Days 51-60, ABTalks 60-Day Claude Challenge.

- `docs/prd.md` — Product Requirements Document (Day 51)
- `docs/blueprint.md` — Implementation Blueprint, Days 52-60 (Day 51)
- `docs/ARCHITECTURE.md`, `SCHEMA.md`, `API.md`, `UI-WIREFRAMES.md`, `PROJECT-STRUCTURE.md` — System Design (Day 52)

**Status:** Day 52 of 60 — system design complete, no production code written yet.
**Live demo:** will be published to GitHub Pages starting Day 54 (first UI milestone).

All data in this project is synthetic. No real patients, clinicians, or healthcare facilities are represented.
